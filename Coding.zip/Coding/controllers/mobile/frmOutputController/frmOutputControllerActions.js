define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnBack **/
    AS_Button_e4ace55746334f04a36662daba4b1f20: function AS_Button_e4ace55746334f04a36662daba4b1f20(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmInput");
        ntf.navigate();
    }
});