define({
    onNavigate: function(params) {
        this.view.lblResult.text = "none";
        for (var data of params.data) {
            if (Number(data.txtCounter.text) === 0) {
                continue;
            }
            if (this.view.lblResult.text == "none") {
                this.view.lblResult.text = data.lblName.text;
            } else {
                this.view.lblResult.text += "\n" + data.lblName.text;
            }
            this.view.lblResult.text += "\t : " + data.txtCounter.text;
        }
    }
});
