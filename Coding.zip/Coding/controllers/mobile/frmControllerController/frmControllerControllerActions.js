define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onclick defined for btnCountUp **/
    AS_Button_j7ce78d375ce451ca0fb36ad112cf39e: function AS_Button_j7ce78d375ce451ca0fb36ad112cf39e(eventobject) {
        var self = this;
        return self.countUp.call(this);
    }
});