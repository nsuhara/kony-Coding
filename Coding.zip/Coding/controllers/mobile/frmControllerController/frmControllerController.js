define({
    //Type your controller code here
    countUp: function() {
        this.view.txtCounter.text = Number(this.view.txtCounter.text) + 1;
    }
 });
