define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onclick defined for btnCountUp **/
    AS_Button_fc36f3db686c462c97637f6de566c6e3: function AS_Button_fc36f3db686c462c97637f6de566c6e3(eventobject) {
        var self = this;
        self.view.txtCounter.text = Number(this.view.txtCounter.text) + 1;
    }
});