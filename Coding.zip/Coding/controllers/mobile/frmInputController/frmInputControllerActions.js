define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onclick defined for btnOutput **/
    AS_Button_a268453dab8247dfb49c27a0c9431718: function AS_Button_a268453dab8247dfb49c27a0c9431718(eventobject) {
        var self = this;
        return self.viewOutput.call(this);
    },
    /** init defined for frmInput **/
    AS_Form_ca34b28e35e648e2bb99c955efabd2e9: function AS_Form_ca34b28e35e648e2bb99c955efabd2e9(eventobject) {
        var self = this;
        return self.initData.call(this);
    }
});