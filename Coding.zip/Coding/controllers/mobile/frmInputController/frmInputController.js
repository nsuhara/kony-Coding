define({
    initData: function() {
        this.view.segList.setData([
            {
                lblName: {
                    text: "Data1"
                },
                txtCounter: {
                    text: 0
                },
                btnCountDown: {
                    onClick: this.countDown.bind(this)
                },
                btnCountUp: {
                    onClick: this.countUp.bind(this)
                }
            },
            {
                lblName: {
                    text: "Data2"
                },
                txtCounter: {
                    text: 0
                },
                btnCountDown: {
                    onClick: this.countDown.bind(this)
                },
                btnCountUp: {
                    onClick: this.countUp.bind(this)
                }
            },
            {
                lblName: {
                    text: "Data3"
                },
                txtCounter: {
                    text: 0
                },
                btnCountDown: {
                    onClick: this.countDown.bind(this)
                },
                btnCountUp: {
                    onClick: this.countUp.bind(this)
                }
            },
            {
                lblName: {
                    text: "Data4"
                },
                txtCounter: {
                    text: 0
                },
                btnCountDown: {
                    onClick: this.countDown.bind(this)
                },
                btnCountUp: {
                    onClick: this.countUp.bind(this)
                }
            },
            {
                lblName: {
                    text: "Data5"
                },
                txtCounter: {
                    text: 0
                },
                btnCountDown: {
                    onClick: this.countDown.bind(this)
                },
                btnCountUp: {
                    onClick: this.countUp.bind(this)
                }
            }
        ]);
    },

    countDown: function(btn, context) {
        var rowIndex = context.rowIndex;
        var sectionIndex = context.sectionIndex;
        var rowData = context.widgetInfo.data[rowIndex];

        if (Number(rowData.txtCounter.text) - 1 < 0) {
            return;
        }
        rowData.txtCounter.text = Number(rowData.txtCounter.text) - 1;

        context.widgetInfo.setDataAt(rowData, rowIndex, sectionIndex);
    },

    countUp: function(btn, context) {
        var rowIndex = context.rowIndex;
        var sectionIndex = context.sectionIndex;
        var rowData = context.widgetInfo.data[rowIndex];

        if (Number(rowData.txtCounter.text) + 1 > 20) {
            return;
        }
        rowData.txtCounter.text = Number(rowData.txtCounter.text) + 1;

        context.widgetInfo.setDataAt(rowData, rowIndex, sectionIndex);
    },

    viewOutput: function() {
        var frmOutput = new kony.mvc.Navigation("frmOutput");
        frmOutput.navigate({data: this.view.segList.data});
    }
});
